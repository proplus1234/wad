/* ═══════════════════════════════════════════════════════════
   ФотоРешалка — фото задания → ответ с объяснением
   ═══════════════════════════════════════════════════════════ */
'use strict';

const $ = (s) => document.querySelector(s);

const els = {
  grades: $('#grades'),
  btnPhoto: $('#btn-photo'),
  btnFile: $('#btn-file'),
  fileInput: $('#file-input'),
  btnText: $('#btn-text'),
  textPanel: $('#text-panel'),
  textInput: $('#text-input'),
  btnSolveText: $('#btn-solve-text'),

  overlay: $('#camera-overlay'),
  animStage: $('#anim-stage'),
  videoStage: $('#video-stage'),
  video: $('#cam-video'),
  vfGrade: $('#vf-grade'),
  flash: $('#flash'),
  btnShutter: $('#btn-shutter'),
  btnClose: $('#btn-close'),
  btnUpload: $('#btn-upload'),

  result: $('#result'),
  resultThumb: $('#result-thumb'),
  resultGrade: $('#result-grade'),
  resultStatus: $('#result-status'),
  resultBody: $('#result-body'),
  resultActions: $('#result-actions'),
  btnCopy: $('#btn-copy'),
  btnAgain: $('#btn-again'),

  btnSettings: $('#btn-settings'),
  settingsModal: $('#settings-modal'),
  cfgProvider: $('#cfg-provider'),
  cfgKey: $('#cfg-key'),
  cfgModel: $('#cfg-model'),
  cfgBaseUrl: $('#cfg-baseurl'),
  fieldBaseUrl: $('#field-baseurl'),
  cfgHelp: $('#cfg-help'),
  linkKey: $('#link-key'),
  cfgSave: $('#cfg-save'),

  toast: $('#toast'),
};

/* ───────────── Настройки (хранятся в браузере) ───────────── */

const CFG_ID = 'fotreshalka_cfg';

const PROVIDERS = {
  gemini: {
    model: 'gemini-2.5-flash',
    link: 'https://aistudio.google.com/apikey',
    help: '1. Нажми «Получить ключ» → войди в Google-аккаунт → «Create API key» → скопируй и вставь выше. Бесплатно, без карты.',
  },
  openrouter: {
    model: 'google/gemini-2.5-flash',
    link: 'https://openrouter.ai/settings/keys',
    help: 'Создай ключ на openrouter.ai. Модели с пометкой «:free» бесплатны, например meta-llama/llama-4-maverick:free',
  },
  custom: {
    model: '',
    link: '',
    help: 'Укажи адрес сервера OpenAI-совместимого API (например http://localhost:1234/v1), название модели и ключ (если нужен).',
  },
};

function getConfig() {
  try {
    return { provider: 'gemini', key: '', model: '', baseUrl: '', ...JSON.parse(localStorage.getItem(CFG_ID) || '{}') };
  } catch {
    return { provider: 'gemini', key: '', model: '', baseUrl: '' };
  }
}

function saveConfig(patch) {
  localStorage.setItem(CFG_ID, JSON.stringify({ ...getConfig(), ...patch }));
}

function openSettings() {
  const cfg = getConfig();
  els.cfgProvider.value = cfg.provider;
  els.cfgKey.value = cfg.key;
  els.cfgKey.placeholder = cfg.key ? 'Ключ уже сохранён ✓ (введи новый, чтобы заменить)' : 'Вставь ключ сюда';
  els.cfgModel.value = cfg.model || PROVIDERS[cfg.provider].model;
  els.cfgBaseUrl.value = cfg.baseUrl || '';
  els.fieldBaseUrl.hidden = cfg.provider !== 'custom';
  updateSettingsHelp();
  els.settingsModal.hidden = false;
}

function updateSettingsHelp() {
  const p = els.cfgProvider.value;
  const info = PROVIDERS[p];
  els.cfgHelp.textContent = info.help;
  els.linkKey.href = info.link || '#';
  els.linkKey.hidden = !info.link;
  if (els.cfgModel.value.trim() === '' && info.model) els.cfgModel.value = info.model;
}

els.cfgProvider.addEventListener('change', () => {
  els.cfgModel.value = PROVIDERS[els.cfgProvider.value].model;
  els.fieldBaseUrl.hidden = els.cfgProvider.value !== 'custom';
  updateSettingsHelp();
});
els.btnSettings.addEventListener('click', openSettings);
els.settingsModal.addEventListener('click', (e) => { if (e.target === els.settingsModal) els.settingsModal.hidden = true; });
els.cfgSave.addEventListener('click', () => {
  saveConfig({
    provider: els.cfgProvider.value,
    key: els.cfgKey.value.trim(),
    model: els.cfgModel.value.trim() || PROVIDERS[els.cfgProvider.value].model,
    baseUrl: els.cfgBaseUrl.value.trim(),
  });
  els.settingsModal.hidden = true;
  showToast('Настройки сохранены ✓');
});

/* ───────────── Выбор класса ───────────── */

let grade = 5;

for (let g = 1; g <= 11; g++) {
  const chip = document.createElement('button');
  chip.className = 'grade-chip' + (g === grade ? ' active' : '');
  chip.textContent = g;
  chip.addEventListener('click', () => {
    grade = g;
    document.querySelectorAll('.grade-chip').forEach((c) => c.classList.remove('active'));
    chip.classList.add('active');
  });
  els.grades.appendChild(chip);
}

/* ───────────── Toast ───────────── */

let toastTimer = null;
function showToast(msg, isErr = false) {
  els.toast.textContent = msg;
  els.toast.classList.toggle('err', isErr);
  els.toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { els.toast.hidden = true; }, 6000);
}

/* ───────────── Камера: анимация → живой просмотр ───────────── */

let stream = null;
let overlayToken = 0; // отменяет старые таймеры/потоки при закрытии

async function openCamera() {
  const token = ++overlayToken;

  els.overlay.hidden = false;
  els.animStage.hidden = false;
  els.videoStage.hidden = true;

  // параллельно: анимация ~1.7 сек и запрос доступа к камере
  const cameraPromise = startStream(token);
  await sleep(1750);
  if (token !== overlayToken) return;

  if (!cameraPromise) {
    // mediaDevices недоступен (небезопасный контекст, напр. file:// в некоторых браузерах)
    closeCamera();
    showToast('Камера доступна только по https или localhost. Нажми «Выбрать фото из файла» или запусти start.bat из папки сайта.', true);
    return;
  }

  try {
    await cameraPromise;
  } catch (e) {
    if (token !== overlayToken) return;
    closeCamera();
    const why = e.name === 'NotAllowedError'
      ? 'Ты запретил доступ к камере. Разреши доступ в настройках браузера (значок 🔒 в адресной строке) и попробуй снова.'
      : e.name === 'NotFoundError'
        ? 'Камера не найдена. Проверь, подключена ли веб-камера, или используй «Выбрать фото из файла».'
        : 'Не удалось открыть камеру: ' + (e.message || e.name);
    showToast(why + ' Можно также выбрать фото из файла.', true);
    return;
  }

  if (token !== overlayToken) return;
  els.animStage.hidden = true;
  els.videoStage.hidden = false;
  els.vfGrade.textContent = grade + ' класс';
}

async function startStream(token) {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return null;
  stream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1440 } },
    audio: false,
  });
  if (token !== overlayToken) { // открытие уже отменили
    stream.getTracks().forEach((t) => t.stop());
    stream = null;
    return null;
  }
  els.video.srcObject = stream;
  await els.video.play().catch(() => {});
  return true;
}

function closeCamera() {
  overlayToken++;
  els.overlay.hidden = true;
  els.flash.classList.remove('go');
  if (stream) {
    stream.getTracks().forEach((t) => t.stop());
    stream = null;
  }
  els.video.srcObject = null;
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

els.btnPhoto.addEventListener('click', openCamera);
els.btnClose.addEventListener('click', closeCamera);

/* ───────────── Снимок ───────────── */

els.btnShutter.addEventListener('click', () => {
  if (!els.video.videoWidth) { showToast('Камера ещё не готова, секунду…'); return; }

  const canvas = document.createElement('canvas');
  canvas.width = els.video.videoWidth;
  canvas.height = els.video.videoHeight;
  canvas.getContext('2d').drawImage(els.video, 0, 0);
  const photo = canvas.toDataURL('image/jpeg', 0.9);

  els.flash.classList.add('go');
  shutterSound();

  setTimeout(() => {
    closeCamera();
    solveImage(photo);
  }, 480);
});

// щелчок затвора через WebAudio
function shutterSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = 'square';
    o.frequency.value = 1400;
    g.gain.setValueAtTime(0.12, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.09);
    o.connect(g).connect(ctx.destination);
    o.start();
    o.stop(ctx.currentTime + 0.1);
    o.frequency.exponentialRampToValueAtTime(500, ctx.currentTime + 0.08);
  } catch { /* без звука тоже можно */ }
}

/* ───────────── Фото из файла (запасной путь) ───────────── */

els.btnFile.addEventListener('click', () => els.fileInput.click());
els.btnUpload.addEventListener('click', () => els.fileInput.click());
els.fileInput.addEventListener('change', () => {
  const file = els.fileInput.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    downscale(reader.result, 1600, (small) => solveImage(small));
  };
  reader.readAsDataURL(file);
  els.fileInput.value = '';
});

// уменьшаем большие фото, чтобы запрос был быстрее
function downscale(dataUrl, maxSide, cb) {
  const img = new Image();
  img.onload = () => {
    const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
    if (scale === 1 && dataUrl.length < 3_000_000) { cb(dataUrl); return; }
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(img.width * scale);
    canvas.height = Math.round(img.height * scale);
    canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
    cb(canvas.toDataURL('image/jpeg', 0.9));
  };
  img.src = dataUrl;
}

/* ───────────── Текстовый режим (работает без ключа) ───────────── */

els.btnText.addEventListener('click', () => {
  els.textPanel.hidden = !els.textPanel.hidden;
  if (!els.textPanel.hidden) els.textInput.focus();
});
els.btnSolveText.addEventListener('click', () => {
  const text = els.textInput.value.trim();
  if (!text) { showToast('Сначала напиши задание 🙂'); return; }
  solveText(text);
});

/* ───────────── Подсказка для нейросети ───────────── */

function buildPrompt(mode = 'photo', extraText = '') {
  const lines = [
    'Ты — добрый, терпеливый учитель для школьника ' + grade + ' класса.',
    mode === 'photo'
      ? 'На фото — школьное задание (математика, русский, английский, физика, химия, биология, история и т.д.).'
      : 'Ниже — школьное задание, написанное текстом.',
    mode === 'photo'
      ? 'Внимательно посмотри на фото. Если заданий несколько — реши первое хорошо читаемое.'
      : 'Определи предмет и тип задания.',
    mode === 'photo'
      ? 'Если текст не читается или на фото нет задания — так и напиши и попроси переснять чётче.'
      : 'Если задание непонятно или не хватает условия — так и напиши, чего не хватает.',
    'Реши задание и ответь строго в таком формате:',
    '**Задание:** коротко, ' + (mode === 'photo' ? 'что написано на фото' : 'суть задания') + '.',
    '**Ответ:** краткий итог (число, слово, буква варианта).',
    '**Объяснение (почему так):** пошагово, простыми словами, на уровне ' + grade + ' класса. Каждый шаг — с новой строки.',
  ];
  if (extraText) lines.push('', 'Задание: ' + extraText);
  return lines.join('\n');
}

/* ───────────── Решение по фото ───────────── */

async function solveImage(photo) {
  const cfg = getConfig();
  if (!cfg.key) {
    showSetupNeeded();
    return;
  }
  showLoading(photo);
  try {
    const prompt = buildPrompt('photo');
    const answer = cfg.provider === 'gemini'
      ? await callGemini(cfg, prompt, photo)
      : await callOpenAICompatible(cfg, prompt, photo);
    showSuccess(answer, photo);
  } catch (e) {
    showError(e.message);
  }
}

// Google Gemini (текст + картинка)
async function callGemini(cfg, prompt, photo) {
  const parts = [{ text: prompt }];
  if (photo) {
    parts.push({ inline_data: { mime_type: 'image/jpeg', data: photo.split(',')[1] } });
  }
  const body = { contents: [{ parts }], generationConfig: { temperature: 0.4 } };
  const models = [cfg.model || 'gemini-2.5-flash', 'gemini-2.0-flash'];

  for (let i = 0; i < models.length; i++) {
    const res = await fetchWithTimeout(
      `https://generativelanguage.googleapis.com/v1beta/models/${models[i]}:generateContent?key=${encodeURIComponent(cfg.key)}`,
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) },
      90000
    );
    if (res.ok) {
      const j = await res.json();
      const text = (j.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('').trim();
      if (text) return text;
      throw new Error('Модель не вернула ответ. Попробуй ещё раз или пересними чётче.');
    }
    if (i === models.length - 1 || ![404, 400].includes(res.status)) {
      const errText = await res.text().catch(() => '');
      if (res.status === 429) throw new Error('Лимит бесплатных запросов исчерпан. Подожди минуту и попробуй снова.');
      if (res.status === 403 || /API key not valid/i.test(errText)) throw new Error('Ключ API недействителен. Проверь его в настройках ⚙️.');
      throw new Error('Ошибка Gemini ' + res.status + '. ' + errText.slice(0, 200));
    }
    // иначе пробуем запасную модель
  }
}

// OpenRouter / любой OpenAI-совместимый API (текст + картинка)
async function callOpenAICompatible(cfg, prompt, photo) {
  const base = (cfg.baseUrl || (cfg.provider === 'openrouter' ? 'https://openrouter.ai/api/v1' : '')).replace(/\/$/, '');
  if (!base) throw new Error('Укажи адрес сервера в настройках ⚙️.');
  const headers = { 'Content-Type': 'application/json' };
  if (cfg.key) headers.Authorization = 'Bearer ' + cfg.key;
  if (cfg.provider === 'openrouter') {
    headers['X-Title'] = 'FotoReshalka';
  }
  const content = photo
    ? [
        { type: 'text', text: prompt },
        { type: 'image_url', image_url: { url: photo } },
      ]
    : prompt;
  const res = await fetchWithTimeout(base + '/chat/completions', {
    method: 'POST',
    headers,
    body: JSON.stringify({ model: cfg.model, max_tokens: 2000, messages: [{ role: 'user', content }] }),
  }, 90000);
  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    if (res.status === 429) throw new Error('Лимит запросов. Подожди минуту и попробуй снова.');
    if (res.status === 401) throw new Error('Ключ API недействителен. Проверь его в настройках ⚙️.');
    throw new Error('Ошибка ' + res.status + '. ' + errText.slice(0, 200));
  }
  const j = await res.json();
  const text = j.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error('Модель не вернула ответ. Попробуй ещё раз.');
  return text;
}

/* ───────────── Решение по тексту (тем же ключом) ───────────── */

async function solveText(text) {
  const cfg = getConfig();
  if (!cfg.key) {
    showSetupNeeded();
    return;
  }
  showLoading(null);
  try {
    const prompt = buildPrompt('text', text);
    const answer = cfg.provider === 'gemini'
      ? await callGemini(cfg, prompt, null)
      : await callOpenAICompatible(cfg, prompt, null);
    showSuccess(answer, null);
  } catch (e) {
    showError(e.message);
  }
}

/* ───────────── Показ результата ───────────── */

let lastAnswer = '';

function showLoading(photo) {
  lastAnswer = '';
  els.result.hidden = false;
  els.resultActions.hidden = true;
  els.resultThumb.hidden = !photo;
  if (photo) els.resultThumb.src = photo;
  els.resultGrade.textContent = grade + ' класс';
  els.resultStatus.textContent = 'Ищу решение…';
  els.resultStatus.className = 'result-status';
  els.resultBody.innerHTML =
    '<div class="skeleton"><i></i><i></i><i></i></div>';
  els.result.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function showSuccess(answer, photo) {
  lastAnswer = answer;
  els.resultStatus.textContent = 'Готово ✓';
  els.resultStatus.className = 'result-status ok';
  els.resultBody.innerHTML = mdToHtml(answer);
  if (photo) els.resultThumb.src = photo;
  els.resultActions.hidden = false;
}

function showError(msg) {
  els.resultStatus.textContent = 'Ошибка';
  els.resultStatus.className = 'result-status err';
  els.resultBody.innerHTML =
    '<p class="err-hint">😕 ' + escapeHtml(msg) + '</p>' +
    '<p class="err-hint">Проверь ключ в настройках ⚙️ или попробуй ещё раз / пересними чётче.</p>';
  els.resultActions.hidden = false;
}

function showSetupNeeded() {
  els.result.hidden = false;
  els.resultActions.hidden = true;
  els.resultGrade.textContent = grade + ' класс';
  els.resultStatus.textContent = 'Нужен бесплатный ключ';
  els.resultStatus.className = 'result-status';
  els.resultThumb.hidden = true;
  els.resultBody.innerHTML =
    '<p>Чтобы решать задания <b>по фото и текстом</b>, подключи бесплатный AI-ключ (1 минута, без карты):</p>' +
    '<p>1. Нажми <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">aistudio.google.com/apikey</a><br>' +
    '2. Войди в Google-аккаунт → «Create API key»<br>' +
    '3. Скопируй ключ → вставь в ⚙️ Настройки</p>' +
    '<p class="err-hint">Если Google недоступен — в настройках ⚙️ можно выбрать OpenRouter или свой сервер.</p>';
  els.result.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

els.btnAgain.addEventListener('click', openCamera);
els.btnCopy.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(lastAnswer);
    showToast('Скопировано ✓');
  } catch {
    const ta = document.createElement('textarea');
    ta.value = lastAnswer;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
    showToast('Скопировано ✓');
  }
});

/* ───────────── Мини-разметка (**жирный**, списки) ───────────── */

function mdToHtml(text) {
  return escapeHtml(text)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/^#{1,4}\s?(.+)$/gm, '<strong>$1</strong>')
    .replace(/^\s*[-*•]\s+(.+)$/gm, '• $1')
    .replace(/\n/g, '<br>');
}

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/* ───────────── fetch с таймаутом ───────────── */

function fetchWithTimeout(url, opts, ms) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  return fetch(url, { ...opts, signal: ctrl.signal }).finally(() => clearTimeout(t));
}
